# Pedido-de-namoro
Pedido de namoro em Python

## Configuração do ambiente de desenvolvimento
Para configurar o ambiente de desenvolvimento, por favor siga os passos abaixo.

1. Instale Python3, Pip3 e o Pipenv.
    * `sudo pip3 install pipenv`
2. Clone este repositório.
    * `git clone git@github.com:gdias00/Pedido-de-namoro.git`
3. Dentro do diretório do repositório, execute os seguintes comandos.
    * `pipenv install`
    * `pipenv shell`

:. Feito com ♥ by Professor Luciano 👋 [Professor Luciano](https://pythonsimplificado.com.br/links)
